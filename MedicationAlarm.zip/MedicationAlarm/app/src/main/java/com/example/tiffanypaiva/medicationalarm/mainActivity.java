package com.example.tiffanypaiva.medicationalarm;

import android.annotation.TargetApi;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class mainActivity extends AppCompatActivity {

    AlarmManager manager;
    TimePicker timepicker;
    TextView text;
    EditText edittext;
    Context context;
    PendingIntent pendingintent;
    Boolean alarmBool;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.context = this;
        this.timepicker = (TimePicker) findViewById(R.id.time_picker);
        this.timepicker.setIs24HourView(true);
        this.edittext = (EditText) findViewById(R.id.edit_text);
        this.text = (TextView)findViewById(R.id.text);
        this.manager = (AlarmManager) getSystemService(ALARM_SERVICE);
        this.alarmBool = false;

        Button setAlarm = (Button) findViewById(R.id.set_alarm);
        Button stopAlarm = (Button) findViewById(R.id.turn_off);


        final Intent intent = new Intent(context, alarmReceiver.class);


        final Calendar calendar = Calendar.getInstance();



        setAlarm.setOnClickListener(new View.OnClickListener() {
            //Necesario para la utilizacion de .getHour() y .getMinute()
            @TargetApi(Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                if(edittext.length()==0){

                    Toast toast = Toast.makeText(getApplicationContext(), R.string.empty, Toast.LENGTH_SHORT);
                    toast.show();
                }else{

                    calendar.set(Calendar.HOUR_OF_DAY, timepicker.getHour());
                    calendar.set(Calendar.MINUTE, timepicker.getMinute());
                    calendar.set(Calendar.SECOND, 0);
                    calendar.set(Calendar.MILLISECOND, 0);


                    int hour = timepicker.getHour();
                    int minute = timepicker.getMinute();
                    String stringHour = String.valueOf(hour);
                    String stringMinute = String.valueOf(minute);
                    setTextAlarm("Alarm Set:"+stringHour + ":"+ stringMinute);
                    alarmBool = true;


                    intent.putExtra("alarmOn", alarmBool);
                    intent.putExtra("medication", edittext.getText().toString());


                    pendingintent = PendingIntent.getBroadcast(mainActivity.this, 0,
                            intent, PendingIntent.FLAG_UPDATE_CURRENT);

                    ;
                    manager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingintent);
                }


            }
        });



        stopAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTextAlarm("Alarm Set Off");


                //Desconectar alarma
                alarmBool = false;
                intent.putExtra("alarmOn", alarmBool);

                sendBroadcast(intent);
            }
        });

    }


    private void setTextAlarm(String string){
        this.text.setText(string);
    }
}