package com.example.tiffanypaiva.medicationalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


    public class alarmReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {


            Boolean bool = (Boolean) intent.getExtras().get("alarmOn");
            String medication = (String) intent.getExtras().get("medication");

            Intent serviceIntent = new Intent(context, alarmService.class);
            serviceIntent.putExtra("alarmOn", bool);
            serviceIntent.putExtra("medication", medication);
            context.startService(serviceIntent);
        }
    }
